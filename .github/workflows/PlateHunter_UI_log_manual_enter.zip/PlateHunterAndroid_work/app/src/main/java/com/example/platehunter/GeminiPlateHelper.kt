package com.example.platehunter

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object GeminiPlateHelper {
    /** Call from a worker thread. Gemini is only a fallback when local extraction fails. */
    fun extractPlate(apiKey: String, transcript: String): String? {
        if (apiKey.isBlank() || transcript.isBlank()) return null
        var conn: HttpURLConnection? = null
        return try {
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=${java.net.URLEncoder.encode(apiKey, "UTF-8")}")
            conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"; connectTimeout = 12000; readTimeout = 12000; doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
            val prompt = "استخرج لوحة سيارة سعودية واحدة فقط من النص التالي. اللوحة 3 حروف عربية ثم 4 أرقام. اكتب الحروف متصلة ثم الأرقام دون مسافات، مثال سرط7520. إذا كانت الأرقام 3 فقط أضف صفرًا في البداية. لا تخمن؛ أعد NONE إن لم تكن واضحة. النص: $transcript"
            val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt))))).toString()
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            if (conn.responseCode !in 200..299) return null
            val raw = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val text = JSONObject(raw).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")
                ?.optJSONArray("parts")?.optJSONObject(0)?.optString("text")?.trim().orEmpty()
            PlateParser.normalize(text).takeIf { it.isNotBlank() }
        } catch (_: Exception) { null } finally { conn?.disconnect() }
    }
    /** Gemini analyzes the COMPLETE Deepgram transcript and returns an ordered, parser-friendly transcript. */
    fun analyzeFullTranscript(apiKey: String, transcript: String): String? {
        if (apiKey.isBlank() || transcript.isBlank()) return null
        var conn: HttpURLConnection? = null
        return try {
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=${java.net.URLEncoder.encode(apiKey, "UTF-8")}")
            conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"; connectTimeout = 20000; readTimeout = 60000; doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
            val prompt = """أنت محلل نص تفريغ صوتي للوحات سيارات سعودية. حلل النص الكامل مرة واحدة، ولا تستخرج لوحة واحدة فقط.
أعد النص مرتبًا كما ورد، مع الحفاظ على كل اللوحات وأسمائها وأنواع المركبات وأوامر الشوارع.
حوّل نطق الحروف إلى الحروف العربية الصحيحة متصلة، وحوّل الأرقام المنطوقة إلى أرقام، واجمع كل لوحة في الصيغة: 3 حروف ثم 4 أرقام، مثال سرط7520.
إذا كانت أرقام لوحة واضحة من 3 خانات فقط أضف صفرًا في البداية. لا تخترع حرفًا أو رقمًا مفقودًا، ولا تحذف لوحة مكتملة.
احتفظ بأوامر الشارع بصيغة «شارع اسم_الشارع» في موضعها؛ عند تغيير الشارع لا تنقل الأمر من مكانه.
احتفظ بكلمات الأنواع: يامه، ونيت، تاكسي، نقل، ميكروباص.
أخرج النص المنظم فقط دون شرح أو علامات Markdown. إن لم تكن اللوحة مؤكدة اترك الكلمات المنطوقة كما هي بدل التخمين.
النص الكامل:
$transcript"""
            val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
                .put("generationConfig", JSONObject().put("temperature", 0)).toString()
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            if (conn.responseCode !in 200..299) return null
            val raw = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            JSONObject(raw).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")
                ?.optJSONArray("parts")?.let { parts -> (0 until parts.length()).mapNotNull { parts.optJSONObject(it)?.optString("text") }.joinToString(" ").trim() }
                ?.takeIf { it.isNotBlank() }
        } catch (_: Exception) { null } finally { conn?.disconnect() }
    }

}
